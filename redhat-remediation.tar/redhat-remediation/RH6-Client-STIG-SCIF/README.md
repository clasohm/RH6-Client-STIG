
SCIF Ansible code for STIG version 1.11

