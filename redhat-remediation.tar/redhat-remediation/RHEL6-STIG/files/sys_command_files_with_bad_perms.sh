#!/bin/bash

find {/sbin/,/bin/,/usr/{{,s}bin/,local/{,s}bin}} -type f -perm /022