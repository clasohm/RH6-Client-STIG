#!/bin/bash

find {/usr/{lib/,lib64},/lib{64,}} -perm /022 -type f