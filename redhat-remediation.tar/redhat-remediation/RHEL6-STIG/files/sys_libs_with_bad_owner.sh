#!/bin/bash

find {/usr/{lib/,lib64},/lib{64,}} -type f ! -user root