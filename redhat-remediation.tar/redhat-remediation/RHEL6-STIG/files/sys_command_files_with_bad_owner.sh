#!/bin/bash

find {/sbin/,/bin/,/usr/{{,s}bin/,local/{,s}bin}} -type f ! -user root