This is the SCIF project to contain the Redhat Audit Remediation files for Ansible.

This is using DOD STIG version 1.11

Release Schedule:

http://iase.disa.mil/stigs/Pages/release-schedule.aspx

Stig Library:

http://iase.disa.mil/stigs/dod-purpose-tool/Pages/index.aspx

Stig Viewer:

http://iase.disa.mil/stigs/Pages/stig-viewing-guidance.aspx

Glen

